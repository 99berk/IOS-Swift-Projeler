//
//  ViewController.swift
//  ebsnakliyat2
//
//  Created by Berk on 1.11.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


}

