//
//  DBUtil.swift
//  ebsnakliyat2
//
//  Created by Berk on 1.11.2022.
//

import Foundation
import SQLite

class DBUtil {
    static var sharedInstance = DBUtil()
    var db: Connection?
    
    let SURUCU_DB = Table("SURUCU_DB")
    let SURUCU_ID = Expression<Int>("SURUCU_ID")
    let ISIM = Expression<String>("ISIM")
    let SOYISIM = Expression<String>("SOYISIM")
    let TELEFON = Expression<String>("TELEFON")
    let ILCE = Expression<String>("ILCE")
    
    let SIPARIS_DB = Table("SIPARIS_DB")
    let SIPARIS_ID = Expression<Int>("SIPARIS_ID")
    let KALKIS_ILCE = Expression<String>("KALKIS_ILCE")
    let VARIS_ILCE = Expression<String>("VARIS_ILCE")
    let ESYA_SAYISI = Expression<String>("ESYA_SAYISI")
    let TARIH = Expression<String>("TARIH")
    let SIPARIS_ONAY = Expression<Bool>("SIPARIS_ONAY")
    
    let ARAC_DB = Table("ARAC_DB")
    let ARAC_ID = Expression<Int>("ARAC_ID")
    let UCRET = Expression<String>("UCRET")
    let KAPASITE = Expression<String>("KAPASITE")
    

    init() {
        var path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        print(path)
        do
        {
            db = try Connection("\(path)/ebs2.sqlite3")
            
            try db!.run(SURUCU_DB.create(temporary: false, ifNotExists: true, block: {
                t in
                t.column(SURUCU_ID,primaryKey: true)
                t.column(ISIM)
                t.column(SOYISIM)
                t.column(TELEFON)
                t.column(ILCE)
            }))
            
            try db!.run(SIPARIS_DB.create(temporary: false, ifNotExists: true, block: {
                k in
                k.column(SIPARIS_ID, primaryKey: true)
                k.column(KALKIS_ILCE)
                k.column(VARIS_ILCE)
                k.column(ESYA_SAYISI)
                k.column(TARIH)
                k.column(SIPARIS_ONAY)
            }))
            
            try db!.run(ARAC_DB.create(temporary: false, ifNotExists: true, block: {
                j in
                j.column(ARAC_ID, primaryKey: true)
                j.column(KAPASITE)
                j.column(UCRET)
            }))
        }
        catch
        {
            print("Hata")
        }
    }
    
    func saveSurucu(isim:String, soyisim:String, telefon:String, ilce:String) {
        do{
            try db!.run(SURUCU_DB.insert(ISIM <- isim, SOYISIM <- soyisim, TELEFON <- telefon, ILCE <- ilce))
        }catch{
            print("Veri tabani ekleme hatasi \(error)");
        }
    }
    
    func saveArac(kapasite:String, ucret:String) {
        do{
            try db!.run(ARAC_DB.insert(KAPASITE <- kapasite, UCRET <- ucret))
        }catch{
            print("Veri tabani ekleme hatasi \(error)");
        }
    }
    
    func saveSiparis(kalkıs: String, varis: String, esya: String, tarih: String, onay: Bool) {
        do {
            try db!.run(SIPARIS_DB.insert(KALKIS_ILCE <- kalkıs, VARIS_ILCE <- varis, ESYA_SAYISI <- esya, TARIH <- tarih, SIPARIS_ONAY <- onay))
        } catch{
            print("Veri tabani ekleme hatasi \(error)")
        }
    }
    
}
